package dev.ahmdaeyz.pinster.ui.newsreader

import androidx.lifecycle.ViewModel

class NewsReaderViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}