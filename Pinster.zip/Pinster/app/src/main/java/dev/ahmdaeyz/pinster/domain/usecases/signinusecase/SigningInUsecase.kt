package dev.ahmdaeyz.pinster.domain.usecases.signinusecase

interface SigningInUsecase {

}