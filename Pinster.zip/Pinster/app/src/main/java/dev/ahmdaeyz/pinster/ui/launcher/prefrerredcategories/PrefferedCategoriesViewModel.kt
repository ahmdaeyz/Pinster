package dev.ahmdaeyz.pinster.ui.launcher.prefrerredcategories

import androidx.lifecycle.ViewModel

class PrefferedCategoriesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}