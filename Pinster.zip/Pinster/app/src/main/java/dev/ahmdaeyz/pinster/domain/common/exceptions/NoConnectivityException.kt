package dev.ahmdaeyz.pinster.domain.common.exceptions

class NoConnectivityException : Exception()