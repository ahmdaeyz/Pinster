package dev.ahmdaeyz.pinster.ui.newsstory

import androidx.lifecycle.ViewModel

class NewsStoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}