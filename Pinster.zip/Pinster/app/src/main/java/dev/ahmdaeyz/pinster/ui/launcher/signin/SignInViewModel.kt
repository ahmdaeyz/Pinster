package dev.ahmdaeyz.pinster.ui.launcher.signin

import androidx.lifecycle.ViewModel

class SignInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}