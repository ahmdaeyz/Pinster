package dev.ahmdaeyz.pinster.data.network

import okhttp3.Interceptor

interface ConnectivityInterceptor : Interceptor {

}
